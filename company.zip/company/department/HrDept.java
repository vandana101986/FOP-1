package company.department;

public class HrDept extends SuperDept{
	
	public String departmentName() {
		return "Welcome to Hr Department";
	}
	
	public String getTodaysWork() {
		return "Fill today's work sheet and mark your attendance";
	}
	
	public String getWorkDeadline() {
		return "Complete by EOD";
	}
	
	public String doActivity() {
		return "Team Lunch";
	}
	
}
