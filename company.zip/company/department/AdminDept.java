package company.department;

public class AdminDept extends SuperDept {

	public String departmentName() {
		return "Welcome to Admin Department";
	}
	
	public String getTodaysWork() {
		return "Complete your document submission";
	}
	
	public String getWorkDeadline() {
		return "Complete by EOD";
	}
	}
